---
name: test-key-comment-filler
description: Tayyor test .xlsx faylida (Question | A | B | C | D | Correct | Comment) har bir savolni ilmiy tekshirib, Correct (to'g'ri javob harfi) va Comment (asos va manba) ustunlarini to'ldirish, imlo va kirill harflarni tuzatish, hisobot yozish bo'yicha universal ish tartibi. Istalgan soha uchun (tibbiyot, parazitologiya, epidemiologiya, mikrobiologiya, huquq va h.k.). "Correct va Comment ni to'ldir", "test kalitini tekshir", "xlsx testga izoh yoz", "kalit va izoh", "_izohli.xlsx" so'rovlarida ishlatiladi.
---

# Test kalitini tekshirish va Correct/Comment ustunlarini to'ldirish (universal)

Tayyor test faylidagi savollarni ilmiy tekshirib, **Correct** va **Comment** ustunlarini to'ldiradi. Asl fayl o'zgarmaydi, natija yangi nom bilan yoziladi. Fayl XML darajasida o'zgartiriladi, shuning uchun uslublar, ustun kengliklari, muzlatilgan qator va ro'yxatli tekshiruv (dataValidation) saqlanadi.

Fayllar: `.kiro/skills/test-key-comment-filler/`
- `scripts/fill_xlsx.py` : javoblar fayllaridan F (Correct) va G (Comment) ni yozadi va avtomatik tekshiruv o'tkazadi
- `scripts/make_report.py` : hisobot `.md` yozadi
- `templates/sources_template.py` : manbalar lug'ati (kalit → to'liq nom) namunasi
- `templates/fixes_template.py` : imlo va kirill tuzatish moduli namunasi (`fix(row, col, text)`)
- `references/answers_format.md` : javoblar fayli formati va yozish qoidalari
- `references/lessons.md` : oldingi seanslarda uchragan muammolar va yechimlar

## 0. Seans boshida (so'raladi)

Bitta xabarda so'rang (berilmagan narsani taxmin qilmang):
1. **Manba fayl** (lokal yo'l yoki GitHub havolasi). GitHub bo'lsa, repo klonlanadi va fayl `/projects/sandbox/<repo>/` dan olinadi.
2. **Natija papkasi** (berilmasa, manba yonida `natija/` yaratiladi).
3. **Soha** (rol), masalan "parazitolog, epidemiolog".
4. **Kutubxona** (ixtiyoriy): foydalanuvchining hujjatlar bazasi, agar bo'lsa (qarang 3-bo'lim).
5. Savol/variant matnini **o'zgartirish ruxsati**: imlo va kirill harflarni tuzatish kerakmi (aniq so'rang, 4-bo'lim).

## 1. Faylni o'qish va reja

Natijani ko'rsating: varaq nomi, qatorlar soni, Correct/Comment to'ldirilganmi, Excel jadvali (`xl/tables`) bormi, matn qayerda saqlanadi (`sharedStrings.xml` yoki `inlineStr`), nechta qatorda kirill harfi bor. Keyin rejani ko'rsating va tasdiq oling.

```
mkdir -p ish && cd ish && unzip -o -q ../fayl.xlsx
```
Savollarni JSON ga ajratish `fill_xlsx.py` ishga tushganda `--work/q.json` ga avtomatik yoziladi. Savollarni o'qish uchun shu faylni chop eting (50-60 tadan).

Faylda 1-qator sarlavha. Ustunlar: A=Question, B..E = variantlar A..D, F=Correct, G=Comment. **Variant harfi ustunga siljigan**: B ustun = "A" varianti, C = "B", D = "C", E = "D".

## 2. Ish tartibi

1. Avval **birinchi 50 savol** namuna sifatida bajariladi, foydalanuvchiga ko'rsatiladi. Tasdiqdan keyin qolganlari 50-60 talik bo'laklarda davom etadi (foydalanuvchi "oxirigacha" desa, to'xtamasdan).
2. Har bo'lak: savollarni chop eting, har birini ilmiy tekshiring, `ans_NN.py` yozing, `fill_xlsx.py` ni ishga tushiring (u har safar hamma `ans_*.py` ni qayta yig'adi va tekshiradi).
3. Oxirida `make_report.py`, so'ng xulosa jadvali.

```
python scripts/fill_xlsx.py --src fayl.xlsx --out natija/fayl_izohli.xlsx --work ish \
  --answers "ish/ans_*.py" --sources ish/sources.py --fixes ish/fixes.py
python scripts/make_report.py --work ish --out natija/fayl_hisobot.md --title fayl --fixes ish/fixes.py
```
Chiqish kodi 1 bo'lsa, tekshiruvda xato bor: faylni topshirmang, xatolarni tuzating. Chiqish kodi 2 bo'lsa, natija fayli Excel'da ochiq (EBUSY): vaqtinchalik papkaga yozildi, foydalanuvchidan faylni yopishni so'rang.

## 3. Correct ustuni qoidalari

- Faqat variant harfi: `A`, `B`, `C` yoki `D`.
- Bir nechta javob haqiqatan to'g'ri bo'lsa, hammasi vergul bilan, alifbo tartibida: `B, D`. Bir xil matnli ikki variant bo'lsa, ikkalasi ham belgilanadi (`C, D`).
- Savol "eng ..." desa, bitta javob tanlanadi, ikkinchi asosli javob bo'lsa **shubhali** deb belgilanadi.
- Mavjud kalitga ko'r-ko'rona ishonmang. Aniq xato bo'lsa tuzating va hisobotga yozing (qator, eski → yangi, sabab). Noaniq bo'lsa harfni o'zgartirmang, **shubhali** deb belgilang.
- Hech bir variant to'g'ri bo'lmasa yoki savol noaniq bo'lsa, eng yaqinini tanlab **shubhali** deb belgilang va sababini yozing. Hech qachon "taxmin" ni aniq fakt qilib ko'rsatmang.
- Aniq son, muddat, hudud, hujjat raqami so'ralgan savolda manbada tasdiqlay olmasangiz: **shubhali** + `Manba: aniq manba topilmadi.`

## 4. Comment ustuni formati

```
To'g'ri javob: <javob matni aynan>. Asos: <1-2 gap ilmiy izoh>. Manba: <manba1>; <manba2>.
```
- "To'g'ri javob:" dan keyin javob katagi matni **belgima-belgi** (tuzatishdan keyingi holatda) ko'chiriladi. Skript buni o'zi qiladi.
- Bir nechta javobda matnlar `; ` bilan ajratiladi, "Asos" hammasini tushuntiradi.
- Izoh o'zbek tilida, lotin yozuvida. Kirill harf yo'q (ko'chirilgan javob matni ham tuzatilgan bo'lishi kerak). Ruscha nomlar lotinda transliteratsiya qilinadi.
- **Faqat haqiqatan mavjud manbalar.** Raqamini aniq bilmagan SanPiN, buyruq yoki hujjatni yozmang. Uydirma manbadan manbasiz yaxshiroq.
- Manbalar bitta lug'atda (`sources.py`: kalit → to'liq nom), hamma savolda bir xil yoziladi. Yangi manba qo'shishdan oldin uning mavjudligini veb-qidiruv bilan tekshiring (WHO, CDC yangiliklari va h.k.).
- Foydalanuvchi kutubxonasidan olingan javob bo'lsa, o'sha hujjat nomi Manba ga yoziladi.

## 5. Kutubxonadan foydalanish (agar foydalanuvchi bersa)

Misol: `https://xayrullokomilov.uz/kutubxona`. Sayt kirishsiz ochilishi mumkin, avval `curl` bilan sinang.
- Qidiruv: `/api/materiallar?q=<so'z>` (lotin va kirill avtomatik moslashadi).
- Matn: `/api/materiallar/<id>` → JSON (`nomi`, `matn`). Hujjat matni ko'pincha **kirillcha**: kalit so'zlarni kirillda `grep` qiling (masalan `Романовский`, `гипнозоит`).
- `/api/materiallar/<id>/fayl` havolasiga brauzerda o'tmang (yuklab olish oynasi ochiladi).
- Kutubxona test to'plamlaridagi kalitlar bilan solishtirish mumkin, lekin ilmiy manbaga zid kalitni ko'r-ko'rona olmang, farqni foydalanuvchiga ayting.
- Kirish talab qilinsa, brauzerda ochib, foydalanuvchidan kirishni so'rang.

## 6. Imlo va kirill harflar

Foydalanuvchi ruxsat bergan bo'lsa (ruxsat bermagan bo'lsa, matnga tegmang, faqat hisobotga yozing):
- Kirill harflarga o'xshash lotin belgilar (`е`, `а`, `о`, `с`, `р`, `х`, `у`, `к` va boshqalar) avtomatik lotinga almashtiriladi (`fixes_template.py` ichidagi `HG`).
- To'liq kirillcha so'zlar `CELL = {(qator, ustun): yangi_matn}` orqali qo'lda tuzatiladi.
- Birlashib ketgan so'zlar ("gelmintozlargaqarshi"), tur nomlari ("PVivax" → "P. vivax"), x/h, `fiksasiya` → `fiksatsiya`, kesilgan qavslar `G` ro'yxati yoki `CELL` orqali tuzatiladi.
- Tuzatishdan oldin matn bo'yicha skaner qiling: uzun tokenlar (>=18 harf), `x` bilan boshlanuvchi so'zlar, yopilmagan qavslar.
- `CELL` kalitida ustun harfi: `A` = savol, `B..E` = variant A..D. Aralashtirib yubormang.
- Tuzatishlar hisobotga (eski → yangi) yoziladi. Apostrof turlarini (`'`, `‘`, `’`) o'zgartirmang.
- Varaq nomi (masalan `Лист1`) savol matni emas, tegmang.

## 7. Avtomatik tekshiruv (har bo'lakdan keyin, skript o'zi bajaradi)

- Savol va variant kataklari kutilgan (tuzatilgan) matnga teng.
- Har Comment "To'g'ri javob: <aynan javob>" bilan boshlanadi, "Manba: ...." bilan tugaydi.
- Izoh va manbada kirill yo'q, A–E kataklarda ham kirill yo'q.
- Correct faqat `A–D` yoki `B, D` ko'rinishida va alifbo tartibida.
- `sheet1.xml` dan boshqa ZIP qismlari asl bilan baytma-bayt bir xil.
- Qo'shimcha: XML to'g'ri ochiladimi (`xml.dom.minidom`), barcha qatorda F va G bormi.

## 8. Hisobot va yakuniy xulosa

`make_report.py` bo'limlari: kaliti tuzatilgan savollar, ko'p javobli savollar, shubhali savollar (qator | kalit | savol | sabab), kirill harflari, imlo tuzatishlari.

Yakuniy xulosada qisqa jadval: nechta savol, nechta kalit tuzatildi, nechta ko'p javobli, nechta shubhali, nechta katak tuzatildi. Alohida yozing: nima tekshirilmadi (masalan, manbalar sahifama-sahifa tekshirilmagan, mahalliy statistika), qaysi savollar foydalanuvchi tekshirishi kerak. Excel'da ochib ko'rilmagan bo'lsa, shuni ayting.

## 9. Fayllarni topshirish

Sandbox'da foydalanuvchi fayl tizimiga kira olmaydi. Natija va hisobotni GitHub'ga yuklang:
- Joriy branch `main` bo'lsa, yangi branch oching (`main` ga commit qilmang), `git add` ni aniq fayl nomlari bilan qiling, `git push -u origin <branch>`.
- Yuklab olish havolasi: `https://github.com/<egasi>/<repo>/raw/<branch>/natija/<fayl>`.
- PR faqat so'ralsa (`gh api repos/.../pulls`; `gh pr create` ishlamaydi).

## Hech qachon

- Savol/variant matnini ruxsatsiz o'zgartirmang.
- Uydirma manba yozmang. Taxminni aniq fakt qilib ko'rsatmang.
- Asl faylni o'zgartirmang. Natija doim yangi nom bilan (`_izohli.xlsx`).
- Hamma shubhali savollarni "to'g'ri" deb ko'rsatmang: foydalanuvchi bilishi kerak.
