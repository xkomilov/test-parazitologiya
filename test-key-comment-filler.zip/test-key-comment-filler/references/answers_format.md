# Javoblar fayli (`ans_NN.py`) formati

Har bo'lak uchun bitta fayl, fayl nomi tartibli (`ans_01.py`, `ans_02.py`, ...). `fill_xlsx.py` hammasini qo'shadi.

```python
EP=['CHERK','MIRT']          # manba kalitlari ro'yxatini qisqartirish uchun (ixtiyoriy)
A={
 # qator: (harflar, asos, [manba kalitlari], holat, eslatma)
 11:("C","Odam uchun yuqumli bosqich sporozoit, u chivin so'lagi bilan kiradi.",['MARKELL','GARCIA'],None,""),
 61:("A, B, C","Asos hammasini tushuntiradi.",['WHOTJ'],'shubhali',"D tasdiqlanmadi."),
 53:("A","Aniq muddat manbada topilmadi.",[],'shubhali',"Muddat tasdiqlanmadi."),   # manbasiz
}
```
- `qator` Excel qator raqami (1-qator sarlavha, savollar 2 dan boshlanadi).
- `harflar`: `"B"` yoki `"A, C"` (vergul + bo'sh joy, alifbo tartibida).
- `asos`: 1-2 gap, o'zbekcha lotin, kirill yo'q. Matnda faqat to'g'ri apostrof ishlating.
- `manba kalitlari`: `sources.py` dagi `S` lug'atidan. Bo'sh ro'yxat bo'lsa, `Manba: aniq manba topilmadi.` yoziladi.
- `holat`: `None` yoki `'shubhali'`.
- `eslatma`: hisobotning "shubhali" jadvalida "sabab" sifatida chiqadi (bo'sh bo'lsa `asos` ishlatiladi).

# Manbalar lug'ati (`sources.py`)

```python
S={ 'KALIT':"To'liq nom (yil)", ... }
```
Boshlang'ich to'plam `templates/sources_template.py` da (WHO, Garcia, Markell va boshqalar). Har yangi manbani qo'shishdan oldin haqiqatan mavjudligini tekshiring.

# Tuzatish moduli (`fixes.py`)

`templates/fixes_template.py` ni nusxalang: `CELL` (qo'lda), `G` (global almashtirishlar), `HG` (kirill-lotin o'xshash belgilar), `fix(row,col,text)`. Tuzatish kerak bo'lmasa `--fixes` bermang.
